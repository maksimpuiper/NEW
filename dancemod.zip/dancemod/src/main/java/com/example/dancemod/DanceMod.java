package com.example.dancemod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.network.packet.s2c.play.StopSoundS2CPacket;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.*;

public class DanceMod implements ModInitializer {
    public static final String MOD_ID = "dancemod";
    public static final Identifier DANCE_ID = Identifier.of(MOD_ID, "dance");
    public static final SoundEvent DANCE_SOUND = SoundEvent.of(DANCE_ID);

    public static Item BOOMBOX;

    // ---- settings you can tweak ----
    static final float MOB_SIZE = 5.0f;              // how huge the mobs are
    static final int SONG_TICKS = 20 * 82;           // party length (song ~81s)
    static final int SPAWN_EVERY = 25;               // ticks between new mobs
    static final int MAX_MOBS = 20;                  // max dancers at once
    static final double MIN_DIST = 9, MAX_DIST = 20; // spawn ring around player
    static final double CUBE_HEIGHT = 32;            // how high above the player the Rubik's cube hangs
    static final double CELL = 4.0;                  // size of one Rubik's cubie (cube = 3 * CELL blocks)
    static final double SPIN_STEP_DEG = 30;          // cube turns this much every second

    // ---- what dances, and what hat each one wears (block, width, height, y-offset; in mob-sizes) ----
    record Hat(String block, double w, double h, double y) {}
    record Kind(String id, List<Hat> hats) {}

    static final List<Kind> KINDS = List.of(
        new Kind("minecraft:skeleton", List.of(   // straw hat
            new Hat("minecraft:hay_block", 1.0, 0.06, 0),
            new Hat("minecraft:hay_block", 0.55, 0.22, 0.06))),
        new Kind("minecraft:creeper", List.of(    // top hat with red band
            new Hat("minecraft:black_concrete", 0.85, 0.05, 0),
            new Hat("minecraft:black_concrete", 0.5, 0.5, 0.05),
            new Hat("minecraft:red_concrete", 0.52, 0.08, 0.05))),
        new Kind("minecraft:pig", List.of(        // red cap
            new Hat("minecraft:red_concrete", 0.7, 0.15, 0),
            new Hat("minecraft:black_concrete", 0.72, 0.06, 0.04))),
        new Kind("minecraft:chicken", List.of(    // party hat
            new Hat("minecraft:blue_concrete", 0.3, 0.35, 0),
            new Hat("minecraft:yellow_concrete", 0.1, 0.1, 0.35))),
        new Kind("minecraft:villager", List.of(   // orange hat
            new Hat("minecraft:orange_concrete", 0.7, 0.12, 0),
            new Hat("minecraft:orange_concrete", 0.4, 0.25, 0.12))),
        new Kind("minecraft:enderman", List.of(   // pink hat
            new Hat("minecraft:pink_concrete", 0.5, 0.12, 0),
            new Hat("minecraft:magenta_concrete", 0.3, 0.2, 0.12)))
    );

    // ---- the giant Rubik's cube (+ colored light beams) ----
    record Elem(String block, double[] c, double[] s) {}
    static final List<Elem> CUBE = buildCube();

    static List<Elem> buildCube() {
        List<Elem> list = new ArrayList<>();
        double K = CELL, half = 1.5 * K;
        list.add(new Elem("minecraft:black_concrete", new double[]{0, 0, 0},
            new double[]{3 * K - 0.1, 3 * K - 0.1, 3 * K - 0.1}));
        String[][] cols = {{"red", "orange"}, {"white", "yellow"}, {"lime", "blue"}};
        for (int axis = 0; axis < 3; axis++) {
            for (int side = 0; side < 2; side++) {
                double sign = side == 0 ? 1 : -1;
                int o1 = (axis + 1) % 3, o2 = (axis + 2) % 3;
                for (int a = -1; a <= 1; a++) {
                    for (int b = -1; b <= 1; b++) {
                        double[] c = new double[3];
                        double[] s = new double[3];
                        c[axis] = sign * (half + 0.05);
                        s[axis] = 0.2;
                        c[o1] = a * K;
                        c[o2] = b * K;
                        s[o1] = K - 0.6;
                        s[o2] = K - 0.6;
                        list.add(new Elem("minecraft:" + cols[axis][side] + "_concrete", c, s));
                    }
                }
            }
        }
        // 4 colored light beams going down from the cube
        String[] glass = {"magenta", "cyan", "lime", "light_blue"};
        double R = 10, top = -7, bottom = -(CUBE_HEIGHT - 1), len = top - bottom;
        double[][] spots = {{R, 0}, {-R, 0}, {0, R}, {0, -R}};
        for (int i = 0; i < 4; i++) {
            list.add(new Elem("minecraft:" + glass[i] + "_stained_glass",
                new double[]{spots[i][0], top - len / 2, spots[i][1]},
                new double[]{1.2, len, 1.2}));
        }
        return list;
    }

    static class Party {
        int ticksLeft = SONG_TICKS;
        double spin = 0;
        double cx, cy, cz;
        final List<UUID> mobs = new ArrayList<>();
        final List<UUID> cube = new ArrayList<>();
    }

    private static final Map<UUID, Party> PARTIES = new HashMap<>();
    private static final Random RNG = new Random();

    @Override
    public void onInitialize() {
        Registry.register(Registries.SOUND_EVENT, DANCE_ID, DANCE_SOUND);

        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(MOD_ID, "boombox"));
        BOOMBOX = Registry.register(Registries.ITEM, key,
            new BoomboxItem(new Item.Settings().registryKey(key).maxCount(1)));

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(e -> e.add(BOOMBOX));

        ServerTickEvents.END_SERVER_TICK.register(DanceMod::tick);
    }

    // ---------- helpers for building commands ----------
    private static String f(double v) { return String.format(Locale.ROOT, "%.4f", v) + "f"; }
    private static String d(double v) { return String.format(Locale.ROOT, "%.4f", v); }

    private static String uuidNbt(UUID u) {
        long m = u.getMostSignificantBits(), l = u.getLeastSignificantBits();
        return "UUID:[I;" + (int) (m >> 32) + "," + (int) m + "," + (int) (l >> 32) + "," + (int) l + "]";
    }

    private static String transform(double[] t, double[] s, double ang) {
        double sy = Math.sin(ang / 2), cy = Math.cos(ang / 2);
        return "transformation:{translation:[" + f(t[0]) + "," + f(t[1]) + "," + f(t[2]) + "],"
            + "scale:[" + f(s[0]) + "," + f(s[1]) + "," + f(s[2]) + "],"
            + "left_rotation:[0f," + f(sy) + ",0f," + f(cy) + "],"
            + "right_rotation:[0f,0f,0f,1f]}";
    }

    private static String elemTransform(Elem e, double ang) {
        double vx = e.c()[0] - e.s()[0] / 2, vy = e.c()[1] - e.s()[1] / 2, vz = e.c()[2] - e.s()[2] / 2;
        double cos = Math.cos(ang), sin = Math.sin(ang);
        double[] t = {vx * cos + vz * sin, vy, -vx * sin + vz * cos};
        return transform(t, e.s(), ang);
    }

    private static void run(ServerWorld world, String cmd) {
        MinecraftServer server = world.getServer();
        ServerCommandSource src = server.getCommandSource().withWorld(world).withSilent();
        server.getCommandManager().executeWithPrefix(src, cmd);
    }

    // ---------- party control ----------
    /** Called when the player right-clicks the boombox. */
    public static void toggleParty(ServerPlayerEntity player) {
        if (PARTIES.containsKey(player.getUuid())) {
            endParty(player.getServer(), player.getUuid(), player);
            player.sendMessage(Text.literal("Вечеринка закончилась"), true);
            return;
        }
        ServerWorld world = (ServerWorld) player.getWorld();
        Party party = new Party();
        party.cx = player.getX();
        party.cy = player.getY() + CUBE_HEIGHT;
        party.cz = player.getZ();
        PARTIES.put(player.getUuid(), party);

        spawnCube(world, party);
        world.playSound(null, player.getBlockPos(), DANCE_SOUND, SoundCategory.RECORDS, 4.0f, 1.0f);
        player.sendMessage(Text.literal("Погнали! Ещё раз ПКМ — стоп"), true);
    }

    private static void spawnCube(ServerWorld world, Party party) {
        for (Elem e : CUBE) {
            UUID id = UUID.randomUUID();
            party.cube.add(id);
            run(world, "summon minecraft:block_display " + d(party.cx) + " " + d(party.cy) + " " + d(party.cz)
                + " {" + uuidNbt(id) + ",Tags:[\"dancemod\"],block_state:{Name:\"" + e.block() + "\"},"
                + "brightness:{sky:15,block:15},view_range:4.0f,interpolation_duration:20,"
                + elemTransform(e, 0) + "}");
        }
    }

    private static void endParty(MinecraftServer server, UUID playerId, ServerPlayerEntity player) {
        Party party = PARTIES.remove(playerId);
        if (party == null || server == null) return;
        for (ServerWorld w : server.getWorlds()) {
            for (UUID id : party.mobs) {
                Entity e = w.getEntity(id);
                if (e != null) {
                    w.spawnParticles(ParticleTypes.CLOUD, e.getX(), e.getY() + 1, e.getZ(), 15, 0.5, 0.5, 0.5, 0.05);
                    for (Entity p : new ArrayList<>(e.getPassengerList())) p.discard();
                    e.discard();
                }
            }
            for (UUID id : party.cube) {
                Entity e = w.getEntity(id);
                if (e != null) e.discard();
            }
        }
        if (player != null) {
            player.networkHandler.sendPacket(new StopSoundS2CPacket(DANCE_ID, SoundCategory.RECORDS));
        }
    }

    private static void tick(MinecraftServer server) {
        for (Map.Entry<UUID, Party> en : new ArrayList<>(PARTIES.entrySet())) {
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(en.getKey());
            Party party = en.getValue();

            if (player == null || --party.ticksLeft <= 0) {
                endParty(server, en.getKey(), player);
                continue;
            }
            ServerWorld world = (ServerWorld) player.getWorld();

            // gradually spawn a new dancer
            if (party.ticksLeft % SPAWN_EVERY == 0 && party.mobs.size() < MAX_MOBS) {
                spawnDancer(world, player, party);
            }

            // spin the Rubik's cube (smoothly, one step per second)
            if (party.ticksLeft % 20 == 0) {
                party.spin += Math.toRadians(SPIN_STEP_DEG);
                for (int i = 0; i < party.cube.size(); i++) {
                    run(world, "data merge entity " + party.cube.get(i)
                        + " {start_interpolation:0,interpolation_duration:20," + elemTransform(CUBE.get(i), party.spin) + "}");
                }
            }

            // colorful light show
            long t = world.getTime();
            if (t % 4 == 0) {
                for (int i = 0; i < 3; i++) {
                    world.spawnParticles(ParticleTypes.NOTE,
                        party.cx + (RNG.nextDouble() - 0.5) * 16, party.cy + (RNG.nextDouble() - 0.5) * 12,
                        party.cz + (RNG.nextDouble() - 0.5) * 16, 0, RNG.nextDouble(), 0, 0, 1.0);
                }
                world.spawnParticles(ParticleTypes.FIREWORK, party.cx, party.cy - 8, party.cz, 3, 5, 3, 5, 0.03);
            }

            // dance
            for (UUID id : party.mobs) {
                Entity e = world.getEntity(id);
                if (!(e instanceof MobEntity mob) || !mob.isAlive()) continue;
                float yaw = mob.getYaw() + 12f;
                mob.setYaw(yaw);
                mob.setBodyYaw(yaw);
                mob.setHeadYaw(yaw);
                if (t % 10 == 0 && mob.isOnGround()) {
                    mob.setVelocity(0, 0.45, 0);
                    mob.velocityModified = true;
                }
            }
        }
    }

    private static void spawnDancer(ServerWorld world, ServerPlayerEntity player, Party party) {
        Kind kind = KINDS.get(RNG.nextInt(KINDS.size()));
        UUID id = UUID.randomUUID();

        double angle = RNG.nextDouble() * Math.PI * 2;
        double dist = MIN_DIST + RNG.nextDouble() * (MAX_DIST - MIN_DIST);
        double x = player.getX() + Math.cos(angle) * dist;
        double z = player.getZ() + Math.sin(angle) * dist;
        double y = player.getY() + 1;
        double S = MOB_SIZE;

        StringBuilder pass = new StringBuilder();
        for (Hat h : kind.hats()) {
            if (pass.length() > 0) pass.append(",");
            pass.append("{id:\"minecraft:block_display\",block_state:{Name:\"").append(h.block()).append("\"},")
                .append("brightness:{sky:15,block:15},")
                .append(transform(new double[]{-h.w() * S / 2, h.y() * S, -h.w() * S / 2},
                                  new double[]{h.w() * S, h.h() * S, h.w() * S}, 0))
                .append("}");
        }
        String extra = kind.id().equals("minecraft:skeleton")
            ? ",ArmorItems:[{},{},{},{id:\"minecraft:leather_helmet\",count:1}],ArmorDropChances:[0.0f,0.0f,0.0f,0.0f]"
            : "";

        run(world, "summon " + kind.id() + " " + d(x) + " " + d(y) + " " + d(z)
            + " {" + uuidNbt(id) + ",NoAI:1b,Silent:1b,Invulnerable:1b,PersistenceRequired:1b,Tags:[\"dancemod\"],"
            + "attributes:[{id:\"minecraft:scale\",base:" + S + "d}],"
            + "Rotation:[" + f(RNG.nextDouble() * 360) + ",0f],"
            + "Passengers:[" + pass + "]" + extra + "}");

        party.mobs.add(id);
        world.spawnParticles(ParticleTypes.NOTE, x, y + 2, z, 8, 1, 1, 1, 1);
        world.spawnParticles(ParticleTypes.CLOUD, x, y + 0.5, z, 20, 1, 0.5, 1, 0.05);
    }
}
